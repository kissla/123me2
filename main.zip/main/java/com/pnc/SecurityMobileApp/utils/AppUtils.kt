package com.pnc.SecurityMobileApp.utils

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowManager

object AppUtils {

    fun setStatusBarColor(activity: Activity, colorCode: Int, lightStatus: Boolean = true) {
        if (!hasMarshmallow()) {
            return
        }
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (lightStatus) {
            activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        activity.window.statusBarColor = colorCode
    }

    fun hasLollipop(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP

    fun hasMarshmallow(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
}