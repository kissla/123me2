package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class FinalizeRegistrationResponse(
    @SerializedName("fidoRegistrationResponse")
    val fidoRegistrationResponse: String,
    @SerializedName("fidoResponseCode")
    val fidoResponseCode: String,
    @SerializedName("fidoResponseMessage")
    val fidoResponseMessage: String,
    @SerializedName("resumePath")
    val resumePath: String
)