package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class CreateRegistrationResponse(
    @SerializedName("challenge")
    val challenge: String,
    @SerializedName("created")
    val created: String,
    @SerializedName("fidoRegistrationRequest")
    val fidoRegistrationRequest: String,
    @SerializedName("href")
    val href: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("policy")
    val policy: Policy,
    @SerializedName("registration")
    val registration: Registration,
    @SerializedName("status")
    val status: String,
    @SerializedName("tenant")
    val tenant: Tenant,
    @SerializedName("updated")
    val updated: String
) {
    data class Policy(
        @SerializedName("href")
        val href: String
    )

    data class Registration(
        @SerializedName("application")
        val application: Application,
        @SerializedName("authenticationRequests")
        val authenticationRequests: AuthenticationRequests,
        @SerializedName("created")
        val created: String,
        @SerializedName("href")
        val href: String,
        @SerializedName("id")
        val id: String,
        @SerializedName("registrationId")
        val registrationId: String,
        @SerializedName("status")
        val status: String,
        @SerializedName("tenant")
        val tenant: Tenant,
        @SerializedName("user")
        val user: User
    ) {
        data class Application(
            @SerializedName("href")
            val href: String
        )

        data class AuthenticationRequests(
            @SerializedName("href")
            val href: String
        )

        data class Tenant(
            @SerializedName("href")
            val href: String
        )

        data class User(
            @SerializedName("href")
            val href: String
        )
    }

    data class Tenant(
        @SerializedName("href")
        val href: String
    )
}