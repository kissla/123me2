package com.pnc.SecurityMobileApp

import android.app.Application
import android.os.Bundle
import android.util.Log
import com.daon.fido.client.ixuaf.Fido
import com.daon.fido.client.ixuaf.FidoFactory
import com.daon.fido.client.sdk.core.FidoSdkFactory
import com.daon.fido.client.sdk.core.IFidoSdk
import com.daon.fido.client.sdk.core.IUafInitialiseCallback
import com.daon.fido.client.sdk.uaf.UafMessageUtils
import com.pnc.SecurityMobileApp.data.AppPreferences

class SecurityMobileApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        initialize()
        val facetId = UafMessageUtils.getFacetId(this)
        Log.i("FACET_ID", facetId)
    }

    private fun initialize() {
        AppPreferences(this).apply {
            clientId = "amg_acp_mobile"
            redirectURI = "securitymobileapp://auth-Response"
        }
        initFido()
    }

    private fun initFido() {
        fidoSDK = FidoSdkFactory.getFidoSdk(this)
        val license = assets.open("license.txt").bufferedReader().use { it.readText() }
        val data = Bundle().apply {
            putString("com.daon.sdk.ados.enabled", "true")
            putString("com.daon.sdk.logs", "true")
            putString("com.daon.sdk.license", license)
        }
        fidoSDK.initialise(data, object : IUafInitialiseCallback {
            override fun onUafInitialiseComplete() {
                Log.i(LOG_TAG, "Initialize complete")
                notifySDKInit(true)
            }

            override fun onUafInitialiseFailed(p0: Int, p1: String?) {
                Log.e(LOG_TAG, "Fido initialization failed. Code = ${p0}, message = ${p1 ?: "s"}")
                notifySDKInit(false)
            }
        })
    }

    companion object {
        lateinit var fidoSDK: IFidoSdk
        const val LOG_TAG: String = "SecurityMobileApp"
        private var listeners: ArrayList<((Boolean) -> Unit)>? = null

        fun registerSDKInitializeListener(listener: ((Boolean) -> Unit)) {
            if (fidoSDK.isInitialised) {
                listener.invoke(true)
            } else {
                ArrayList<((Boolean) -> Unit)>().also {
                    it.add(listener)
                    listeners = it;
                }
            }
        }

        private fun notifySDKInit(isSuccess: Boolean) {
            listeners?.forEach {
                it.invoke(isSuccess)
            }
            listeners?.clear()
            listeners = null
        }
    }
}