package com.pnc.SecurityMobileApp.model

import com.google.gson.annotations.SerializedName

data class RegistrationInfo(
    @SerializedName("policy")
    val policy: Policy,
    @SerializedName("registration")
    val registration: Registration
) {
    data class Policy(
        @SerializedName("application")
        val application: Application,
        @SerializedName("policyId")
        val policyId: String
    ) {
        data class Application(
            @SerializedName("applicationId")
            val applicationId: String
        )
    }

    data class Registration(
        @SerializedName("application")
        val application: Application,
        @SerializedName("registrationId")
        val registrationId: String,
        @SerializedName("user")
        val user: User
    ) {
        data class Application(
            @SerializedName("applicationId")
            val applicationId: String
        )

        data class User(
            @SerializedName("href")
            val href: String
        )
    }
}