package com.pnc.SecurityMobileApp.ui.adapters

import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.daon.fido.client.sdk.model.Authenticator
import com.daon.fido.client.sdk.model.AuthenticatorReg
import com.pnc.SecurityMobileApp.R

class AuthenticatorsRecyclerViewAdapter(private val authenticatorsList: ArrayList<ArrayList<Authenticator>>) :
    RecyclerView.Adapter<AuthenticatorsRecyclerViewAdapter.ViewHolder>() {

    private var itemClickListener: ((ArrayList<Authenticator>) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.authenticator_icon_layout, parent, false)
        val holder = ViewHolder(itemView)
        holder.itemView.setOnClickListener { view ->
            (view.tag as? Int)?.also {
                itemClickListener?.invoke(authenticatorsList.get(it))
            }
        }
        return holder
    }

    override fun getItemCount(): Int {
        return authenticatorsList.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemView.tag = position
        authenticatorsList[position].forEach { auth ->
            if (auth.userVerification != 512L) {
                holder.textView.text = ""
                (auth as? AuthenticatorReg)?.also {
                    if (it.isRegistered) {
                        holder.textView.text = "Registered"
                    }
                }
                val iconString = auth.icon.substring(auth.icon.indexOfFirst { it == ',' } + 1)
                Base64.decode(iconString, 0).also {
                    val bitmap = BitmapFactory.decodeByteArray(it, 0, it.count())
                    holder.imageView.setImageBitmap(bitmap)
                }
                return@forEach
            }
        }
    }

    fun setItemClickListener(listener: ((ArrayList<Authenticator>) -> Unit)) {
        itemClickListener = listener
    }

    fun addAuthenticators(list: ArrayList<Authenticator>) {
        authenticatorsList.add(list)
        notifyDataSetChanged()
    }

    fun addAuthenticators(list: Array<Authenticator>) {
        ArrayList<Authenticator>().apply {
            list.iterator().forEach {
                add(it)
            }
        }.also {
            authenticatorsList.add(it)
            notifyDataSetChanged()
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val textView: TextView = itemView.findViewById(R.id.textView)
    }
}