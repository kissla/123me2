package com.pnc.SecurityMobileApp.ui.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class RedirectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent.data?.getQueryParameter("code")?.also { code: String ->
            startActivity(
                Intent(
                    applicationContext,
                    LoginActivity::class.java
                ).apply { putExtra("code", code) })
        }
        finish()
    }
}