package com.pnc.SecurityMobileApp.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.daon.fido.client.sdk.core.*
import com.daon.fido.client.sdk.model.Authenticator
import com.daon.fido.client.sdk.model.AuthenticatorReg
import com.daon.fido.client.sdk.model.DiscoveryData
import com.daon.fido.client.sdk.ui.AuthenticatorChooser
import com.pnc.SecurityMobileApp.SecurityMobileApplication
import com.pnc.SecurityMobileApp.api.MFAOauthService
import com.pnc.SecurityMobileApp.api.MFAOauthTokenService
import com.pnc.SecurityMobileApp.api.MFAResumePathService
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.SingleshotAuthenticationResponse
import com.pnc.SecurityMobileApp.ui.UIUtils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import okhttp3.ResponseBody
import retrofit2.HttpException

class LauncherActivity : AppCompatActivity() {

    private lateinit var authenticatorChooser: AuthenticatorChooser
    private lateinit var disposables: CompositeDisposable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        if (savedInstanceState == null) {
//            Intent(applicationContext, MainActivity::class.java).also {
//                startActivity(it)
//            }
//            finish()
//            return
//        }
        disposables = CompositeDisposable()
        authenticatorChooser = AuthenticatorChooser(this, AUTHENTICATOR_CHOOSE_REQUEST_CODE)
        checkBiometricsRegistered()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        authenticatorChooser.processActivityResult(requestCode, resultCode, data)
    }

    private fun checkBiometricsRegistered() {
        SecurityMobileApplication.registerSDKInitializeListener { isSuccess: Boolean ->
            if (isSuccess.not()) {
                return@registerSDKInitializeListener
            }
            SecurityMobileApplication.fidoSDK.discover(object : IUafDiscoverCallback {

                override fun onUafDiscoverFailed(code: Int, error: String?) {
                    Log.e(LOG_TAG, error ?: "onUafDiscoverFailed")
                }

                override fun onUafDiscoverComplete(discoveryData: DiscoveryData?) {
                    var registered: Boolean = false
                    discoveryData?.availableAuthenticators?.forEach { authenticator: Authenticator ->
                        (authenticator as? AuthenticatorReg)?.also { auth: AuthenticatorReg ->
                            if (auth.aaid != "D409#0602" && auth.isRegistered) {
                                registered = true
                                return@forEach
                            }
                        }
                    }
                    if (registered) {
                        loginWithBiometrics();
                    } else {
                        Intent(applicationContext, LoginActivity::class.java).also {
                            startActivity(it)
                            finish()
                        }
                    }
                }
            })
        }
    }

    private fun loginWithBiometrics() {
        val prefs: AppPreferences = AppPreferences(applicationContext)
        val request =
            SingleShotAuthenticationRequest.createLoginWithAuthenticator(
                prefs.fidoAppId ?: "",
                prefs.aaid ?: ""
            )
        SecurityMobileApplication.fidoSDK.authenticate(
            request.toString(),
            IFidoSdk.AuthenticatorFilter.Unregistered,
            object : AuthenticationCallback() {
                override fun chooseAuthenticator(
                    authenticators: Array<out Array<Authenticator>>?,
                    callback: IChooseAuthenticatorCallback?
                ) {
                    authenticatorChooser.chooseAuthenticator(authenticators, callback)
                }

                override fun onUafAuthenticationComplete(response: String?) {
                    if (!TextUtils.isEmpty(response)) {
                        onAuthenticateSuccess(response!!)
                    }
                }

                override fun onUafAuthenticationFailed(error: Error?) {
                    Log.e(LOG_TAG, error?.message ?: "onUafAuthenticationFailed")
                }
            })
    }

    @SuppressLint("CheckResult")
    private fun onAuthenticateSuccess(response: String) {
        val subscription =
            MFAOauthService.createSingleShotAuthentication(applicationContext, response)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe({ response: SingleshotAuthenticationResponse ->
                    AppPreferences(applicationContext).apply {
                        fidoRegistrationRequestId = response.fidoAuthenticationRequestId
                        resumePath = response.resumePath
                    }
                    authenticateFido(response.fidoAuthenticationRequest)
                }, { ex: Throwable ->
                    println(ex.message)
                })
        disposables.add(subscription)
    }

    private fun authenticateFido(fidoResponse: String) {
        SecurityMobileApplication.fidoSDK.authenticate(fidoResponse, object :
            AuthenticationCallback() {
            override fun chooseAuthenticator(
                authenticators: Array<out Array<Authenticator>>?,
                callback: IChooseAuthenticatorCallback?
            ) {
                authenticatorChooser.chooseAuthenticator(
                    authenticators, callback
                )
            }

            override fun onUafAuthenticationComplete(response: String?) {
                finalizeAuthentication(response)
            }

            override fun onUafAuthenticationFailed(error: Error?) {
            }
        })
    }

    private fun finalizeAuthentication(fidoResponse: String?) {
        val subscription = MFAResumePathService.finalizeAuthentication(
            applicationContext,
            AppPreferences(applicationContext).fidoRegistrationRequestId ?: "",
            fidoResponse ?: ""
        ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe({ response ->
                SecurityMobileApplication.fidoSDK.notifyUafResult(
                    fidoResponse ?: "",
                    response.fidoResponseCode.toShort()
                )
                notifyAuthentication()
            }, {
                println(it.message)
            })
        disposables.add(subscription)
    }

    private fun notifyAuthentication() {
        val prefs = AppPreferences(applicationContext)
        val subscription = MFAResumePathService.notifyAuthentication(
            applicationContext,
            prefs.fidoRegistrationRequestId ?: "",
            prefs.idxUserId ?: ""
        ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe({
            UIUtils.showOkAlertDialog(
                this,
                "Error",
                "Notify API call failed. Please login using your credentials"
            )
        }, { exception: Throwable ->
            (exception as? HttpException)?.code()?.also { code: Int ->
                if (code != 302) {
                    return@also
                }
                exception.response()?.headers()?.get("Location")?.also { url: String ->
                    handleRedirection(url)
                }
            }
        })
        disposables.add(subscription)
    }

    private fun handleRedirection(url: String) {
        val code: String? = Uri.parse(url).getQueryParameter("code")
        if (TextUtils.isEmpty(code)) {
            UIUtils.showOkAlertDialog(
                this,
                "Error",
                "Authentication Resume call failed. Please login using your credentials."
            )
            return
        }
        AppPreferences(applicationContext).authCode = code
        val subscription =
            MFAOauthTokenService.getOauthToken(applicationContext)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ response ->
                    AppPreferences(applicationContext).referenceToken =
                        response.accessToken
                    Intent(
                        applicationContext,
                        MainActivity::class.java
                    ).also { intent ->
                        startActivity(intent)
                        finish()
                    }
                }, {
                    UIUtils.showOkAlertDialog(
                        this,
                        title = "Error",
                        message = "Auth Token API call failed. Please login using your credentials"
                    )
                })
        disposables.add(subscription)
    }

    companion object {
        const val LOG_TAG: String = "LauncherActivity"
        const val AUTHENTICATOR_CHOOSE_REQUEST_CODE: Int = 0xFEED
    }

}