package com.pnc.SecurityMobileApp.api

import com.google.gson.GsonBuilder
import com.pnc.SecurityMobileApp.BuildConfig
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object ApiHelper {

    private val cookieJar: CookieJar = createCookieJar()

    fun getOauthTokenService(): MFAOauthTokenService {
        return getRetrofit(BuildConfig.BASE_URL).create(MFAOauthTokenService::class.java)
    }

    fun getPingAccessService(): MFAPingAccessService {
        return getRetrofit(BuildConfig.PING_ACCESS_DOMAIN_URL).create(MFAPingAccessService::class.java)
    }

    fun getOauthService(): MFAOauthService {
        return getRetrofit(BuildConfig.BASE_URL).create(MFAOauthService::class.java)
    }

    fun getResumePathService(): MFAResumePathService {
        return getRetrofit(BuildConfig.BASE_URL).create(MFAResumePathService::class.java)
    }

    private fun getRetrofit(url:String): Retrofit {
        val client = getUnsafeOkHttpClient()
            .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
            .cookieJar(cookieJar)
            .build()

        return Retrofit.Builder().baseUrl("https://$url")
            .client(client)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder().setLenient().create()
                )
            )
            .build()
    }

    private fun createCookieJar(): CookieJar {
        return object : CookieJar {
            private var cookies: List<Cookie>? = null

            override fun loadForRequest(url: HttpUrl): List<Cookie> {
                return cookies ?: emptyList()
            }

            override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
                this.cookies = ArrayList(cookies)
            }
        }
    }

    private fun getUnsafeOkHttpClient(): OkHttpClient.Builder {
        return try {
            // Create a trust manager that does not validate certificate chains
            val trustAllCerts: Array<TrustManager> = arrayOf(
                object : X509TrustManager {

                    @Throws(CertificateException::class)
                    override fun checkClientTrusted(
                        chain: Array<X509Certificate?>?,
                        authType: String?
                    ) {
                    }

                    @Throws(CertificateException::class)
                    override fun checkServerTrusted(
                        chain: Array<X509Certificate?>?,
                        authType: String?
                    ) {
                    }

                    override fun getAcceptedIssuers(): Array<X509Certificate> {
                        return arrayOf()
                    }
                }
            )

            // Install the all-trusting trust manager
            val sslContext: SSLContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())
            // Create an ssl socket factory with our all-trusting manager
            val sslSocketFactory: SSLSocketFactory = sslContext.socketFactory
            val builder: OkHttpClient.Builder = OkHttpClient.Builder()
            builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            builder.hostnameVerifier(HostnameVerifier { _, _ -> true })
            builder.addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
            builder.followRedirects(false).followSslRedirects(false)
            builder
        } catch (e: Exception) {
            throw RuntimeException(e)
        }
    }
}