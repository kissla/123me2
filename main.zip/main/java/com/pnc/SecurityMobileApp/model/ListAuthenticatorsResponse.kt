package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class ListAuthenticatorsResponse(
    @SerializedName("href")
    val href: String,
    @SerializedName("items")
    val items: List<Item>,
    @SerializedName("metadata")
    val metadata: Metadata,
    @SerializedName("paging")
    val paging: Paging
) {
    data class Item(
        @SerializedName("appCorrelationId")
        val appCorrelationId: String,
        @SerializedName("appVersion")
        val appVersion: String,
        @SerializedName("application")
        val application: Application,
        @SerializedName("attestation")
        val attestation: String,
        @SerializedName("authenticatorAttestationId")
        val authenticatorAttestationId: String,
        @SerializedName("authenticatorCounter")
        val authenticatorCounter: Int,
        @SerializedName("authenticatorId")
        val authenticatorId: String,
        @SerializedName("authenticatorType")
        val authenticatorType: AuthenticatorType,
        @SerializedName("created")
        val created: String,
        @SerializedName("deviceCorrelationId")
        val deviceCorrelationId: String,
        @SerializedName("facetId")
        val facetId: String,
        @SerializedName("href")
        val href: String,
        @SerializedName("id")
        val id: String,
        @SerializedName("lastUsed")
        val lastUsed: String,
        @SerializedName("make")
        val make: String,
        @SerializedName("model")
        val model: String,
        @SerializedName("osVersion")
        val osVersion: String,
        @SerializedName("publicKeyId")
        val publicKeyId: String,
        @SerializedName("registration")
        val registration: Registration,
        @SerializedName("registrationChallenge")
        val registrationChallenge: RegistrationChallenge,
        @SerializedName("status")
        val status: String,
        @SerializedName("tenant")
        val tenant: Tenant,
        @SerializedName("type")
        val type: String,
        @SerializedName("updated")
        val updated: String,
        @SerializedName("user")
        val user: User
    ) {
        data class Application(
            @SerializedName("href")
            val href: String
        )

        data class AuthenticatorType(
            @SerializedName("href")
            val href: String
        )

        data class Registration(
            @SerializedName("href")
            val href: String
        )

        data class RegistrationChallenge(
            @SerializedName("href")
            val href: String
        )

        data class Tenant(
            @SerializedName("href")
            val href: String
        )

        data class User(
            @SerializedName("href")
            val href: String
        )
    }

    data class Metadata(
        @SerializedName("limit")
        val limit: Int,
        @SerializedName("page")
        val page: Int,
        @SerializedName("totalCount")
        val totalCount: Int
    )

    data class Paging(
        @SerializedName("first")
        val first: Any,
        @SerializedName("last")
        val last: Any,
        @SerializedName("next")
        val next: Any,
        @SerializedName("previous")
        val previous: Any
    )
}