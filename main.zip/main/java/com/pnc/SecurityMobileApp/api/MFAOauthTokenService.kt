package com.pnc.SecurityMobileApp.api

import android.content.Context
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.OauthTokenResponse
import com.pnc.SecurityMobileApp.utils.AppUtils
import io.reactivex.Single
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Headers
import retrofit2.http.POST

interface MFAOauthTokenService {

    @FormUrlEncoded
    @POST("/as/token.oauth2")
    @Headers(
        "Content-Type: application/x-www-form-urlencoded",
        "Accept-Encoding: gzip, deflate",
        "Accept-Language: en-US,en;q=0.9",
        "Accept: application/json, text/plain, */*"
    )
    fun getOauthToken(
        @Field("client_id") clientId: String,
        @Field("code_verifier") codeVerifier: String,
        @Field("grant_type") grantType: String,
        @Field("code") code: String,
        @Field("redirect_uri") redirectURI: String
    ): Single<OauthTokenResponse>

    companion object {
        fun getOauthToken(context: Context): Single<OauthTokenResponse> {
            val prefs: AppPreferences = AppPreferences(context)
            return ApiHelper.getOauthTokenService().getOauthToken(
                clientId = prefs.clientId ?: "",
                codeVerifier = prefs.codeVerifier ?: "",
                grantType = "authorization_code",
                code = prefs.authCode ?: "",
                redirectURI = prefs.redirectURI ?: ""
            )
        }
    }
}