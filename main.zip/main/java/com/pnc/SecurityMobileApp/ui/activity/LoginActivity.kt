package com.pnc.SecurityMobileApp.ui.activity

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.daon.fido.client.sdk.model.AuthenticatorReg
import com.daon.fido.client.sdk.uaf.UafMessageUtils
import com.pnc.SecurityMobileApp.utils.AppUtils
import com.pnc.SecurityMobileApp.BuildConfig
import com.pnc.SecurityMobileApp.R
import com.pnc.SecurityMobileApp.SecurityMobileApplication
import com.pnc.SecurityMobileApp.api.ApiHelper
import com.pnc.SecurityMobileApp.api.MFAOauthTokenService
import com.pnc.SecurityMobileApp.data.AppPreferences
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.HttpException
import java.security.MessageDigest
import java.security.SecureRandom


class LoginActivity : AppCompatActivity() {

    private lateinit var codeVerifier: String
    private lateinit var codeChallenge: String
    private lateinit var disposables: CompositeDisposable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        initialize()
    }

    private fun initialize() {
        AppUtils.setStatusBarColor(this, Color.WHITE, true)
        setSupportActionBar(toolBar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        disposables = CompositeDisposable()
        loadLoginPage()
    }


    private fun loadLoginPage() {
        val url: String = getURLToLoad()
        val tabsIntent = CustomTabsIntent.Builder().build()
        tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_HISTORY)
        tabsIntent.launchUrl(this, Uri.parse(url))
//        webView.settings.javaScriptEnabled = true
//        webView.webViewClient = getWebViewClient()
//        pageLoadingIndicator.visibility = View.VISIBLE
//        val urlToLoad = getURLToLoad()
//        webView.loadUrl(urlToLoad)
    }

    private fun getWebViewClient(): WebViewClient {
        return object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageLoadingIndicator.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageLoadingIndicator.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                if (AppUtils.hasLollipop() && request != null
                    && request.url.scheme != null && request.url.scheme!!.equals("securitymobileapp")
                ) {
                    val code: String? = request.url.getQueryParameter("code")
                    code?.also {
                        performOauthTokenRequest(it)
                    }
                    return true
                }
                return false
            }

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null) {
                    val uri = Uri.parse(url)
                    if (uri.scheme != null && uri.scheme!!.equals("securitymobileapp")) {
                        val code: String? = uri.getQueryParameter("code")
                        code?.also {
                            performOauthTokenRequest(it)
                        }
                        return true
                    }
                }
                return super.shouldOverrideUrlLoading(view, url)
            }
        }
    }

    private fun getURLToLoad(): String {
        codeVerifier = createCodeVerifier()
        codeChallenge = createCodeChallenge(codeVerifier)
        AppPreferences(applicationContext).codeVerifier = codeVerifier
        AppPreferences(applicationContext).codeChallenge = codeChallenge
        return "https://${BuildConfig.BASE_URL}/as/authorization.oauth2?response_type=code" +
                "&code_challenge_method=S256" +
                "&code_challenge=${codeChallenge}" +
                "&client_id=${getClientId()}" +
                "&redirect_uri=${getRedirectURI()}" +
                "&state=bFJsQ0ZzbGdyWDJaWWdSUktjRFF-bFdjdHlrR0lMUUg0Mkx4ZHVFY1l2SGdILkM2WHE" +
                "&scope=openid%20profile"
    }

    private fun createCodeChallenge(data: String): String {
        return Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(data.toByteArray()),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )
            .replace("\\s".toRegex(), "")
    }

    private fun createCodeVerifier(): String {
        val array = ByteArray(32)
        SecureRandom().nextBytes(array)
        return Base64.encodeToString(array, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            .replace("\\s".toRegex(), "")
    }

    private fun getClientId(): String {
        return "amg_acp_mobile"
    }

    private fun getRedirectURI(): String {
        return "securitymobileapp://auth-Response"
    }

    private fun performOauthTokenRequest(code: String) {
        AppPreferences(applicationContext).authCode = code
        val disposable = MFAOauthTokenService.getOauthToken(
            applicationContext
        ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe({ response ->
                AppPreferences(applicationContext).referenceToken = response.accessToken
                decideNavigation()
            }) { throwable ->
                (throwable as? HttpException)?.response()?.errorBody()?.string()?.also {
                    AlertDialog.Builder(this)
                        .setPositiveButton("Ok") { dialog: DialogInterface?, _: Int -> dialog?.dismiss() }
                        .setMessage(it).show()
                }
            }
        disposables.add(disposable)
    }

    private fun decideNavigation() {
        val disposable = Single.fromCallable {
            val discoveryData = SecurityMobileApplication.fidoSDK.discover()
            var registered = false
            for (auth in discoveryData.availableAuthenticators) {
                if ((auth as? AuthenticatorReg)?.isRegistered == true) {
                    registered = true
                    break
                }
            }
            registered
        }.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe({ registered ->
                if (registered) {
                    val launchIntent = Intent(applicationContext, MainActivity::class.java)
                    startActivity(launchIntent)
                } else {
                    val launchIntent = Intent(applicationContext, UserConsentActivity::class.java)
                    startActivity(launchIntent)
                }
            }, {

            })
        disposables.add(disposable)
    }

    override fun onNewIntent(newIntent: Intent?) {
        super.onNewIntent(newIntent)
        val code: String? = newIntent?.getStringExtra("code")
        code?.also {
            performOauthTokenRequest(it)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
    }

}