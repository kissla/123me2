package com.pnc.SecurityMobileApp.api

import android.content.Context
import com.google.gson.JsonObject
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.RegistrationResponse
import com.pnc.SecurityMobileApp.model.SingleshotAuthenticationResponse
import io.reactivex.Single
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface MFAOauthService {

    @POST("/as/authorization.oauth2")
    fun createSingleShotAuthentication(
        @Header("Authorization") authorization: String,
        @Query("client_id") clientId: String,
        @Query("redirect_uri") redirectURI: String,
        @Query("response_type") responseType: String,
        @Query("code_challenge_method") codeChallengeMethod: String,
        @Query("code_challenge") codeChallenge: String,
        @Query("acr_values") acrValues: String,
        @Query("scope") scope: String,
        @Body data: JsonObject
    ): Single<SingleshotAuthenticationResponse>


    @GET("/as/authorization.oauth2")
    fun createSilentAndBiometricRegistration(
        @Header("Authorization") authorization: String,
        @Query("client_id") clientId: String,
        @Query("redirect_uri") redirectURI: String,
        @Query("response_type") responseType: String,
        @Query("code_challenge_method") codeChallengeMethod: String,
        @Query("code_challenge") codeChallenge: String,
        @Query("acr_values") acrValues: String,
        @Query("scope") scope: String
    ): Single<RegistrationResponse>

    companion object {

        fun createSingleShotAuthentication(
            context: Context,
            fidoAuthResponse: String
        ): Single<SingleshotAuthenticationResponse> {
            val prefs = AppPreferences(context)
            val data = JsonObject().apply {
                addProperty("fidoAuthenticationResponse", fidoAuthResponse)
                addProperty("biometricServerData", "")
            }
            val token = prefs.referenceToken
            val clientId = prefs.clientId
            val redirectURI = prefs.redirectURI
            val challenge = prefs.codeChallenge
            println(token + clientId + redirectURI + challenge)
            return ApiHelper.getOauthService().createSingleShotAuthentication(
                authorization = "Bearer ${prefs.referenceToken}",
                clientId = prefs.clientId ?: "",
                redirectURI = prefs.redirectURI ?: "",
                responseType = "code",
                codeChallengeMethod = "S256",
                codeChallenge = prefs.codeChallenge ?: "",
                acrValues = "amg.auth.loa2",
                scope = "USER",
                data = data
            )
        }

        fun createSilentAndBiometricRegistration(
            context: Context,
            create: Boolean
        ): Single<RegistrationResponse> {
            val prefs = AppPreferences(context)
            return ApiHelper.getOauthService().createSilentAndBiometricRegistration(
                authorization = "Bearer ${prefs.referenceToken}",
                clientId = prefs.clientId ?: "",
                redirectURI = prefs.redirectURI ?: "",
                responseType = "code",
                codeChallengeMethod = "S256",
                codeChallenge = prefs.codeChallenge ?: "",
                acrValues = if (create) "amg.reg.and" else "amg.reg",
                scope = "REGISTRATION"
            )
        }

        fun createANDRegistration(context: Context): Single<RegistrationResponse> {
            return createSilentAndBiometricRegistration(context, true)
        }

    }
}