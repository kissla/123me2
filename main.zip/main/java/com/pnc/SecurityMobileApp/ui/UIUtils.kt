package com.pnc.SecurityMobileApp.ui

import android.app.Activity
import android.content.DialogInterface
import android.util.DisplayMetrics
import android.util.TypedValue
import androidx.appcompat.app.AlertDialog

object UIUtils {

    fun dpToPix(metrics: DisplayMetrics, dp: Int): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), metrics).toInt()
    }

    fun showOkAlertDialog(
        activity: Activity,
        title: String?,
        message: String? = "",
        okClickListener: (() -> Unit)? = null
    ) {
        showAlertDialog(
            activity = activity,
            title = title,
            message = message,
            positiveText = "Ok",
            positiveListener = okClickListener
        )
    }

    fun showAlertDialog(
        activity: Activity,
        title: String? = null,
        message: String? = null,
        positiveText: String? = null,
        positiveListener: (() -> Unit)? = null,
        negativeText: String? = null,
        negativeListener: (() -> Unit)? = null
    ) {
        val builder = AlertDialog.Builder(activity).setTitle(title).setMessage(message)
        positiveText?.also {
            builder.setPositiveButton(
                it
            ) { dialog, _ ->
                positiveListener?.invoke()
                dialog?.dismiss()
            }
        }
        negativeText?.also {
            builder.setNegativeButton(it) { dialog, _ ->
                negativeListener?.invoke()
                dialog?.dismiss()
            }
        }
        val dialog = builder.create()
        dialog.show()
    }
}