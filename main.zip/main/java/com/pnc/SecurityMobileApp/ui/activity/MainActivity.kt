package com.pnc.SecurityMobileApp.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.daon.fido.client.sdk.core.IUafDiscoverCallback
import com.daon.fido.client.sdk.model.Authenticator
import com.daon.fido.client.sdk.model.AuthenticatorReg
import com.daon.fido.client.sdk.model.DiscoveryData
import com.daon.fido.client.sdk.state.Keys
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.gson.Gson
import com.pnc.SecurityMobileApp.utils.AppUtils
import com.pnc.SecurityMobileApp.R
import com.pnc.SecurityMobileApp.SecurityMobileApplication
import com.pnc.SecurityMobileApp.api.MFAOauthService
import com.pnc.SecurityMobileApp.api.MFAPingAccessService
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.ListAuthenticatorsResponse
import com.pnc.SecurityMobileApp.model.MFAAuthenticator
import com.pnc.SecurityMobileApp.model.RegistrationInfo
import com.pnc.SecurityMobileApp.ui.UIUtils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.HttpException

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var bottomSheetBehavior: BottomSheetBehavior<View>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initialize()
    }

    private fun initialize() {
        AppUtils.setStatusBarColor(
            this,
            ContextCompat.getColor(this, android.R.color.holo_blue_dark)
        )
        setSupportActionBar(toolBar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheetLayout)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        menuImageView.setOnClickListener(this)
        goToAuthManager.setOnClickListener(this)
        goToSettings.setOnClickListener(this)
        cancel_action.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.menuImageView -> {
                onMenuImageViewClick()
            }
            R.id.goToAuthManager -> {
                goToAuthManager()
            }
            R.id.goToSettings -> {

            }
            R.id.cancel_action -> {
                bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            }
        }
    }

    private fun goToAuthManager() {
        SecurityMobileApplication.fidoSDK.discover(object : IUafDiscoverCallback {
            override fun onUafDiscoverFailed(code: Int, error: String?) {
            }

            override fun onUafDiscoverComplete(discoveryData: DiscoveryData?) {
                var isRegistered = false
                discoveryData?.availableAuthenticators?.forEach { authenticator: Authenticator ->
                    (authenticator as? AuthenticatorReg)?.isRegistered?.also {
                        isRegistered = it
                        return@forEach
                    }
                }
                if (isRegistered) {
                    authenticatorsManagementFlow()
                } else {
                    UIUtils.showAlertDialog(
                        this@MainActivity,
                        message = "There are no authenticators currently registered. Would you like to register one?",
                        title = "Register Authenticator",
                        positiveText = "Ok",
                        positiveListener = {
                            firstTimeRegistrationFlow()
                        },
                        negativeText = "Cancel"
                    )
                }
            }
        })
    }

    private fun authenticatorsManagementFlow() {
        MFAPingAccessService.listAuthenticators(applicationContext).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({
                onListAuthenticatorsResponse(it)
            }, {
                println(it.message)
            })
    }

    private fun onListAuthenticatorsResponse(authenticatorsResponse: ListAuthenticatorsResponse) {
        SecurityMobileApplication.fidoSDK.discover(object : IUafDiscoverCallback {
            override fun onUafDiscoverFailed(code: Int, error: String?) {
            }

            override fun onUafDiscoverComplete(discoveryData: DiscoveryData?) {
                val authenticatorsList: ArrayList<ArrayList<Authenticator>> = arrayListOf()
                val authenticatorIdList: ArrayList<MFAAuthenticator> = arrayListOf()
                discoveryData?.availableAuthenticators?.forEach { authenticator: Authenticator ->
                    authenticatorsResponse.items?.forEach { item ->
                        if (authenticator.aaid != "D409#0602" && authenticator.aaid == item.authenticatorAttestationId) {
                            val keys: Keys = SecurityMobileApplication.fidoSDK.getKeys(
                                AppPreferences(
                                    applicationContext
                                ).fidoAppId ?: ""
                            )
                            keys.forEach { key ->
                                if (key.isValid) {
                                    if (key.keyId == item.authenticatorId) {
                                        authenticatorsList.add(arrayListOf(authenticator))
                                        authenticatorIdList.add(
                                            MFAAuthenticator(
                                                authenticator.aaid,
                                                item.authenticatorId
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }


                MFAPingAccessService.createRegistrationRequest(applicationContext)
                    .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ response ->
                        AppPreferences(applicationContext).apply {
                            fidoRegistrationRequestId = response.id
                        }
                        Intent(
                            applicationContext,
                            ManageAvailableAuthenticatorsActivity::class.java
                        ).apply {
                            putExtra(
                                ManageAvailableAuthenticatorsActivity.KEY_FIDO_REGISTRATION_REQUEST_DATA,
                                response.fidoRegistrationRequest
                            )
                            putExtra(
                                ManageAvailableAuthenticatorsActivity.KEY_AUTHENTICATOR_MANAGEMENT_FLOW,
                                true
                            )
                            val listBundle: Bundle = Bundle()
                            authenticatorsList.forEachIndexed { index, list ->
                                var bundle: Bundle = Bundle()
                                list.forEachIndexed { _index, authenticator ->
                                    bundle.putString(
                                        _index.toString(),
                                        Gson().toJson(authenticator)
                                    )
                                }
                                listBundle.putBundle(index.toString(), bundle)
                            }
                            val idBundle = Bundle()
                            authenticatorIdList.forEachIndexed { index, mfaAuthenticator ->
                                idBundle.putString(
                                    index.toString(),
                                    Gson().toJson(mfaAuthenticator)
                                )
                            }
                            putExtra(
                                ManageAvailableAuthenticatorsActivity.KEY_AUTHENTICATORS,
                                listBundle
                            )
                            putExtra(
                                ManageAvailableAuthenticatorsActivity.KEY_AUTHENTICATOR_IDS,
                                idBundle
                            )
                        }.also {
                            startActivity(it)
                        }
                    }, {
                        println(it.message)
                    })
            }
        })
    }

    private fun firstTimeRegistrationFlow() {
        MFAOauthService.createANDRegistration(applicationContext).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({ response ->
                AppPreferences(applicationContext).apply {
                    fidoRegistrationRequestId = response.fidoRegistrationRequestId
                    idxUserId = response.idxUserId
                    resumePath = response.idxUserId
                    daonGuid = response.daonGuid
                }
                Intent(
                    applicationContext,
                    ManageAvailableAuthenticatorsActivity::class.java
                ).apply {
                    putExtra(
                        ManageAvailableAuthenticatorsActivity.KEY_FIDO_REGISTRATION_REQUEST_DATA,
                        response.fidoRegistrationRequest
                    )
                }.also {
                    startActivity(it)
                }
            }, {
                when (it) {
                    is HttpException -> {
                        if (it.code() == 302) {
                            UIUtils.showOkAlertDialog(
                                this,
                                title = "Error",
                                message = "createANDRegistration: status code 302 returned"
                            )
                        } else {
                            UIUtils.showOkAlertDialog(
                                this,
                                title = "Error",
                                message = "createANDRegistration failed"
                            )
                        }
                    }
                    else -> {
                        UIUtils.showOkAlertDialog(
                            this,
                            title = "Error",
                            message = "createANDRegistration failed"
                        )
                    }
                }
            })
    }

    private fun onMenuImageViewClick() {
        if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_COLLAPSED ||
            bottomSheetBehavior.state == BottomSheetBehavior.STATE_HIDDEN
        ) {
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        } else if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) {
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        }
    }
}