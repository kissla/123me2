package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class SingleshotAuthenticationResponse(
    @SerializedName("daonGuid")
    val daonGuid: String,
    @SerializedName("fidoAuthenticationRequest")
    val fidoAuthenticationRequest: String,
    @SerializedName("fidoAuthenticationRequestId")
    val fidoAuthenticationRequestId: String,
    @SerializedName("policy")
    val policy: String,
    @SerializedName("resumePath")
    val resumePath: String
)