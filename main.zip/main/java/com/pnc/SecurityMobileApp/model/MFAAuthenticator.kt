package com.pnc.SecurityMobileApp.model

data class MFAAuthenticator(val aaid: String, val authenticatorId: String)