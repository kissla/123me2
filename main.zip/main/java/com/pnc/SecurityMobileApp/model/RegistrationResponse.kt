package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class RegistrationResponse(
    @SerializedName("daonGuid")
    val daonGuid: String,
    @SerializedName("fidoRegistrationRequest")
    val fidoRegistrationRequest: String,
    @SerializedName("fidoRegistrationRequestId")
    val fidoRegistrationRequestId: String,
    @SerializedName("idxUserId")
    val idxUserId: String,
    @SerializedName("policy")
    val policy: String,
    @SerializedName("resumePath")
    val resumePath: String
)