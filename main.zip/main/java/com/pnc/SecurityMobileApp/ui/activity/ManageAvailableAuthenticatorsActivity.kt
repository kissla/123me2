package com.pnc.SecurityMobileApp.ui.activity

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import com.daon.fido.client.sdk.core.*
import com.daon.fido.client.sdk.model.Authenticator
import com.daon.fido.client.sdk.model.AuthenticatorReg
import com.daon.fido.client.sdk.ui.AuthenticatorChooser
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators
import com.google.gson.Gson
import com.pnc.SecurityMobileApp.R
import com.pnc.SecurityMobileApp.SecurityMobileApplication
import com.pnc.SecurityMobileApp.api.MFAOauthTokenService
import com.pnc.SecurityMobileApp.api.MFAPingAccessService
import com.pnc.SecurityMobileApp.api.MFAResumePathService
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.MFAAuthenticator
import com.pnc.SecurityMobileApp.ui.UIUtils
import com.pnc.SecurityMobileApp.ui.adapters.AuthenticatorsRecyclerViewAdapter
import com.pnc.SecurityMobileApp.ui.adapters.GridAutofitLayoutManager
import com.pnc.SecurityMobileApp.ui.adapters.SpaceItemDecoration
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_show_authenticators.*
import retrofit2.HttpException

class ManageAvailableAuthenticatorsActivity : AppCompatActivity() {

    private lateinit var disposables: CompositeDisposable
//    private lateinit var authenticatorChooser: AuthenticatorChooser

    private var authenticatorsList: ArrayList<ArrayList<Authenticator>> = arrayListOf()
    private var authenticatorsIdList: ArrayList<MFAAuthenticator> = arrayListOf()
    private var adapter: AuthenticatorsRecyclerViewAdapter? = null
    private var authenticatorCallback: IChooseAuthenticatorCallback? = null
    private var fidoRegistrationRequest: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_authenticators)
        initialize()
        executeDaon()
    }

    private fun initialize() {
        initDataFromIntent()
        setSupportActionBar(toolBar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        authenticatorsRecyclerView.addItemDecoration(SpaceItemDecoration())
        authenticatorsRecyclerView.layoutManager =
            GridAutofitLayoutManager(this, UIUtils.dpToPix(resources.displayMetrics, 150))

        adapter = AuthenticatorsRecyclerViewAdapter(authenticatorsList)
        adapter?.setItemClickListener { list ->
            onAuthenticatorSelected(list)
        }
        authenticatorsRecyclerView.adapter = adapter
        disposables = CompositeDisposable()
    }

    private fun onAuthenticatorSelected(list: ArrayList<Authenticator>) {
        var isRegistered = false
        var auth: Authenticator? = null
        list.forEach { _auth ->
            if (_auth.userVerification != 512L && (_auth as? AuthenticatorReg)?.isRegistered == true) {
                isRegistered = true
                auth = _auth
                return@forEach
            }
        }
        if (isRegistered) {
            auth?.also {
                UIUtils.showAlertDialog(
                    this,
                    title = "Deregister Authenticator",
                    message = "Do you want to deregister authenticator",
                    positiveText = "No",
                    negativeText = "Yes",
                    negativeListener = {
                        deregisterAuthenticator(it)
                    })
            }
            return
        }
        if (authenticatorCallback != null) {
            list.forEach { auth ->
                if (auth.userVerification == 512L) {
                    AppPreferences(applicationContext).aaid = auth.aaid
                    return@forEach
                }
            }
            val array = list.toTypedArray()
            authenticatorCallback?.onChooseAuthenticatorComplete(array)
//            (list.toArray() as? Array<Authenticator>)?.also { array ->
//                authenticatorCallback?.onChooseAuthenticatorComplete(array)
//            }
            authenticatorCallback = null
        }
    }


    private fun deregisterAuthenticator(authenticator: Authenticator) {
        var authenticatorId: String? = null
        authenticatorsIdList.forEach {
            if (it.aaid == authenticator.aaid) {
                authenticatorId = it.id
                return@forEach
            }
        }
        if (authenticatorId == null) {
            return
        }
        val subscription =
            MFAPingAccessService.deregisterAuthenticator(applicationContext, authenticatorId!!)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe({response ->
                    deregisterFidoAuthenticator(response.fidoDeregistrationRequest, authenticator)
                }, {
                    println(it.message)
                })
        disposables.add(subscription)
    }

    private fun deregisterFidoAuthenticator(fidoRequestData: String, authenticator: Authenticator) {
        SecurityMobileApplication.fidoSDK.deregister(fidoRequestData,
            object : IUafDeregistrationCallback {
                override fun onUafDeregistrationComplete() {
                    val iterator = authenticatorsList.iterator()
                    iterator.forEach { list ->
                        list.forEach { auth ->
                            if (auth.aaid == authenticator.aaid) {
                                iterator.remove()
                            }
                        }
                    }
                    adapter?.notifyDataSetChanged()
                    MFAPingAccessService.createRegistrationRequest(applicationContext)
                        .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ response ->
                            AppPreferences(applicationContext).fidoRegistrationRequestId =
                                response.id
                            fidoRegistrationRequest = response.fidoRegistrationRequest
                            executeDaon()
                        }, {

                        })
                }

                override fun onUafDeregistrationFailed(code: Int, error: String?) {
                }
            })
    }

    private fun initDataFromIntent() {
        intent.getBundleExtra(KEY_AUTHENTICATORS)?.also { mainBundle ->
            val mainList: ArrayList<ArrayList<Authenticator>> = ArrayList()
            mainBundle.keySet().forEach { mainKey ->
                mainBundle.getBundle(mainKey)?.also { subBundle ->
                    val subList: ArrayList<Authenticator> = ArrayList()
                    subBundle.keySet().forEach { subKey ->
                        subBundle.getString(subKey)?.also { _data ->
                            val authenticator = Gson().fromJson(_data, AuthenticatorReg::class.java)
                            subList.add(authenticator)
                        }
                    }
                    if (subList.isNotEmpty()) {
                        mainList.add(subList)
                    }
                }
            }
            if (mainList.isNotEmpty()) {
                authenticatorsList.addAll(mainList)
            }
        }
        intent.getBundleExtra(KEY_AUTHENTICATOR_IDS)?.also { mainBundle ->
            mainBundle.keySet().forEach { key ->
                mainBundle.getString(key)?.also { _data ->
                    val _auth = Gson().fromJson(_data, MFAAuthenticator::class.java)
                    authenticatorsIdList.add(_auth)
                }
            }
        }
        fidoRegistrationRequest = intent.getStringExtra(KEY_FIDO_REGISTRATION_REQUEST_DATA)
    }

    private fun executeDaon() {
//        authenticatorChooser = AuthenticatorChooser(this, AUTHENTICATOR_CHOOSE_REQUEST_CODE)
        SecurityMobileApplication.fidoSDK.register(
            fidoRegistrationRequest ?: "",
            object : IUafRegistrationCallback {
                override fun onUafRegistrationFailed(error: Error?) {
                    if (intent.getBooleanExtra(KEY_AUTHENTICATOR_MANAGEMENT_FLOW, false).not()) {
                        UIUtils.showOkAlertDialog(
                            this@ManageAvailableAuthenticatorsActivity,
                            "SDK Error",
                            "Please go to Authenticator Mangagement to register authenticator"
                        )
                    }
                }

                override fun onPagedUIAuthenticatorsReady(authenticators: PagedUIAuthenticators?) {
                }

                override fun chooseAuthenticator(
                    authenticators: Array<out Array<Authenticator>>?,
                    callback: IChooseAuthenticatorCallback?
                ) {
                    authenticators?.asList()?.also { list ->
                        val mainList: ArrayList<ArrayList<Authenticator>> = ArrayList()
                        list.forEach {
                            val subList: ArrayList<Authenticator> = ArrayList()
                            subList.addAll(it.toList())
                            mainList.add(subList)
                        }
                        authenticatorsList.addAll(mainList)
                        adapter?.notifyDataSetChanged()
                    }
                    authenticatorCallback = callback
                }

                override fun onUafRegistrationComplete(response: String?) {
                    intent.getBooleanExtra(KEY_AUTHENTICATOR_MANAGEMENT_FLOW, false).also {
                        if (it) {
                            handleAuthenticatorManagementFlow(response)
                        } else {
                            handleGeneralFlow(response)
                        }
                    }
                }
            })
    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        val array = data?.getStringArrayExtra("chosenAuthenticatorSet")
//        AppPreferences(applicationContext).aaid = array?.getOrElse(1) { "" }
//        authenticatorChooser.processActivityResult(requestCode, resultCode, data)
//    }

    private fun handleAuthenticatorManagementFlow(fidoResponse: String? = "") {
        val subscription = MFAPingAccessService.updateRegistrationRequest(
            applicationContext,
            fidoResponse ?: ""
        ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe({
            val data = it.string()
            println(data)
        }, {
            println(it.message)
        })
        disposables.add(subscription)
    }

    private fun handleGeneralFlow(fidoResponse: String? = "") {
        val subscription = MFAResumePathService.finalizeRegistration(
            applicationContext,
            fidoRegResponse = fidoResponse ?: ""
        ).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe({ response ->
                SecurityMobileApplication.fidoSDK.notifyUafResult(
                    fidoResponse ?: "",
                    response.fidoResponseCode.toShort()
                )
                notifyRegistration()
            }, {
                println(it.message)
            })
        disposables.add(subscription)
    }

    private fun notifyRegistration() {
        val subscription = MFAResumePathService.notifyRegistration(applicationContext)
            .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                UIUtils.showOkAlertDialog(
                    this,
                    title = "Error",
                    message = "NotifyANDProcessing API call failed though authenticator is registered. No Action is required"
                )
            }, { exception ->
                (exception as? HttpException)?.code()?.also { code: Int ->
                    if (code != 302) {
                        return@also
                    }
                    exception.response()?.headers()?.get("Location")?.also { url: String ->
                        handleRedirection(url)
                    }
                }
            })
        disposables.add(subscription)
    }

    private fun handleRedirection(url: String) {
        Uri.parse(url).getQueryParameter("code")?.also { code: String ->
            AppPreferences(applicationContext).authCode = code
            val subscription2 =
                MFAOauthTokenService.getOauthToken(applicationContext)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ response ->
                        AppPreferences(applicationContext).referenceToken =
                            response.accessToken
                        Intent(
                            applicationContext,
                            MainActivity::class.java
                        ).also { intent ->
                            startActivity(intent)
                            finish()
                        }
                    }, {
                        UIUtils.showOkAlertDialog(
                            this,
                            title = "Error",
                            message = "Auth Token API call failed though authenticator is registered. No action is required"
                        )
                    })
            disposables.add(subscription2)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return false
    }

    companion object {
        const val KEY_FIDO_REGISTRATION_REQUEST_DATA: String = "fidoRegistrationRequest"
        const val KEY_AUTHENTICATOR_MANAGEMENT_FLOW: String = "authenticatorManagementFlow"
        const val KEY_AUTHENTICATORS: String = "authenticators"
        const val KEY_AUTHENTICATOR_IDS: String = "authenticator_ids"
    }
}