package com.pnc.SecurityMobileApp.ui.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.pnc.SecurityMobileApp.R
import com.pnc.SecurityMobileApp.api.MFAOauthService
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.ui.UIUtils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_user_consent.*
import retrofit2.HttpException


class UserConsentActivity : AppCompatActivity() {
    private val disposables: CompositeDisposable = CompositeDisposable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_consent)
        initUI()
    }

    private fun initUI() {
        setSupportActionBar(toolBar)
        supportActionBar?.setDisplayShowHomeEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        val disclaimer =
            "PNC will check that a unique key resides on your mobile device solely for the purpose of verifying your identity. " +
                    "No other information such as subscriber and device details will be examined." +
                    "<a href=\"https://www.pnc.com/en/privacy-policy.html\"> See PNC’s Privacy Policy for how we treat your data.</a>"
        val textSpanned: Spanned
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            textSpanned = Html.fromHtml(disclaimer, 0)
        } else {
            textSpanned = Html.fromHtml(disclaimer)
        }
        contentTextView.text = textSpanned

        agreedButton.setOnClickListener {
            val subscription = MFAOauthService.createANDRegistration(applicationContext)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe({ response ->
                    AppPreferences(applicationContext).apply {
                        daonGuid = response.daonGuid
                        fidoRegistrationRequestId = response.fidoRegistrationRequestId
                        idxUserId = response.idxUserId
                        resumePath = response.resumePath
                        val appId: String =
                            GsonBuilder().setLenient().setPrettyPrinting().create()
                                .fromJson(response.fidoRegistrationRequest, JsonArray::class.java)
                                .get(0)
                                .asJsonObject.getAsJsonObject("header").get("appID")
                                .asJsonPrimitive.asString
                        fidoAppId = appId
                    }
                    val launchIntent =
                        Intent(
                            applicationContext,
                            ManageAvailableAuthenticatorsActivity::class.java
                        ).apply {
                            putExtra(
                                ManageAvailableAuthenticatorsActivity.KEY_FIDO_REGISTRATION_REQUEST_DATA,
                                response.fidoRegistrationRequest
                            )
                        }
                    startActivity(launchIntent)
                }, {
                    val okClickListener = {
                        Intent(applicationContext, MainActivity::class.java).also {
                            startActivity(it)
                            finish()
                        }
                        Unit
                    }
                    when (it) {
                        is HttpException -> {
                            if (it.code() == 302) {
                                UIUtils.showOkAlertDialog(
                                    this,
                                    "Error",
                                    message = "Status code 302 returned. Please go to Authenticator Management to register authenticator",
                                    okClickListener = okClickListener
                                )
                            } else {
                                UIUtils.showOkAlertDialog(
                                    this,
                                    "Error",
                                    message = "CreateANDRegistration API call failed. Please go to Authenticator Management to register authenticator",
                                    okClickListener = okClickListener
                                )
                            }
                        }
                        else -> {
                            UIUtils.showOkAlertDialog(
                                this,
                                "Error",
                                message = "CreateANDRegistration API call failed. Please go to Authenticator Management to register authenticator",
                                okClickListener = okClickListener
                            )
                        }
                    }
                })
            disposables.add(subscription)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
    }
}