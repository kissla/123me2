package com.pnc.SecurityMobileApp.api

import android.content.Context
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.FinalizeAuthenticationResponse
import com.pnc.SecurityMobileApp.model.FinalizeRegistrationResponse
import io.reactivex.Single
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface MFAResumePathService {

    @POST
    fun sendRequest(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Body data: JsonObject
    ): Single<ResponseBody>

    companion object {

        fun sendRequest(
            url: String,
            authorization: String,
            fidoRequestId: String,
            fidoResponse: String,
            idxUserId: String,
            isRegistration: Boolean
        ): Single<ResponseBody> {
            val data = JsonObject().apply {
                addProperty(
                    if (isRegistration) "fidoRegistrationRequestId" else "fidoAuthenticationRequestId",
                    fidoRequestId
                )
                addProperty(
                    if (isRegistration) "fidoRegistrationResponse" else "fidoAuthenticationResponse",
                    fidoResponse
                )
                addProperty("idxUserId", idxUserId)
            }

            return ApiHelper.getResumePathService().sendRequest(url, authorization, data)
        }

        fun finalizeRegistration(
            url: String,
            authorization: String,
            fidoRegRequestId: String,
            fidoRegResponse: String
        ): Single<FinalizeRegistrationResponse> {
            return sendRequest(
                url = url,
                authorization = authorization,
                fidoRequestId = fidoRegRequestId,
                fidoResponse = fidoRegResponse,
                idxUserId = "",
                isRegistration = true
            ).flatMap { responseBody ->
                Single.fromCallable {
                    val data = responseBody.string()
                    val response = GsonBuilder().setLenient().create()
                        .fromJson(data, FinalizeRegistrationResponse::class.java)
                    response
                }
            }
        }

        fun finalizeRegistration(
            context: Context,
            fidoRegResponse: String
        ): Single<FinalizeRegistrationResponse> {
            val prefs = AppPreferences(context)
            return finalizeRegistration(
                prefs.resumePath ?: "",
                authorization = "Bearer ${prefs.referenceToken}",
                fidoRegRequestId = prefs.fidoRegistrationRequestId ?: "",
                fidoRegResponse = fidoRegResponse
            )
        }

        fun notifyRegistration(
            url: String,
            authorization: String,
            fidoRegRequestId: String,
            idxUserId: String
        ): Single<ResponseBody> {
            return sendRequest(
                url = url,
                authorization = authorization,
                fidoRequestId = fidoRegRequestId,
                fidoResponse = "",
                idxUserId = idxUserId,
                isRegistration = true
            )
        }

        fun notifyRegistration(
            context: Context
        ): Single<ResponseBody> {
            val prefs = AppPreferences(context)
            return notifyRegistration(
                prefs.resumePath ?: "",
                authorization = "Bearer ${prefs.referenceToken}",
                fidoRegRequestId = prefs.fidoRegistrationRequestId ?: "",
                idxUserId = prefs.idxUserId ?: ""
            )
        }

        fun finalizeAuthentication(
            url: String,
            authorization: String,
            fidoAuthRequestId: String,
            fidoAuthResponse: String
        ): Single<FinalizeAuthenticationResponse> {
            return sendRequest(
                url = url,
                authorization = authorization,
                fidoRequestId = fidoAuthRequestId,
                fidoResponse = fidoAuthResponse,
                idxUserId = "",
                isRegistration = false
            ).flatMap { responseBody ->
                Single.fromCallable {
                    val data = responseBody.string()
                    val response = GsonBuilder().setLenient().create()
                        .fromJson(data, FinalizeAuthenticationResponse::class.java)
                    response
                }
            }
        }

        fun finalizeAuthentication(
            context: Context,
            fidoAuthRequestId: String,
            fidoAuthResponse: String
        ): Single<FinalizeAuthenticationResponse> {
            val prefs = AppPreferences(context)
            return finalizeAuthentication(
                prefs.resumePath ?: "",
                authorization = "Bearer ${prefs.referenceToken}",
                fidoAuthRequestId = fidoAuthRequestId,
                fidoAuthResponse = fidoAuthResponse
            )
        }

        fun notifyAuthentication(
            url: String,
            authorization: String,
            fidoAuthRequestId: String,
            idxUserId: String
        ): Single<ResponseBody> {
            return sendRequest(
                url = url,
                authorization = authorization,
                fidoRequestId = fidoAuthRequestId,
                fidoResponse = "",
                idxUserId = idxUserId,
                isRegistration = false
            )
        }

        fun notifyAuthentication(
            context: Context,
            fidoAuthRequestId: String,
            idxUserId: String
        ): Single<ResponseBody> {
            val prefs = AppPreferences(context)
            return notifyAuthentication(
                prefs.resumePath ?: "",
                authorization = "Bearer ${prefs.referenceToken}",
                fidoAuthRequestId = fidoAuthRequestId,
                idxUserId = idxUserId
            )
        }
    }
}