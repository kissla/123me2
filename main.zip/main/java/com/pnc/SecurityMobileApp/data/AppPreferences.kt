package com.pnc.SecurityMobileApp.data

import android.content.Context
import android.content.SharedPreferences
import kotlin.reflect.KProperty

class AppPreferences private constructor(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)

    var fidoAppId: String? by StringPreference(sharedPreferences, "fido_app_id")
    var codeVerifier: String? by StringPreference(sharedPreferences, "code_verifier")
    var codeChallenge: String? by StringPreference(sharedPreferences, "code_challenge")
    var authCode: String? by StringPreference(sharedPreferences, "auth_code")
    var referenceToken: String? by StringPreference(sharedPreferences, "reference_token")
    var clientId: String? by StringPreference(sharedPreferences, "client_id")
    var redirectURI: String? by StringPreference(sharedPreferences, "redirect_uri")
    var daonGuid: String? by StringPreference(sharedPreferences, "daonGuid")
    var fidoRegistrationRequestId: String? by StringPreference(
        sharedPreferences,
        "fidoRegistrationRequestId"
    )
    var idxUserId: String? by StringPreference(sharedPreferences, "idxUserId")
    var resumePath: String? by StringPreference(sharedPreferences, "resumePath")
    var aaid: String? by StringPreference(sharedPreferences, "aaid")

    companion object {

        private var instance: AppPreferences? = null
        operator fun invoke(context: Context): AppPreferences {
            return instance ?: synchronized(this) {
                instance ?: AppPreferences(context).also { instance = it }
            }
        }
    }

    class StringPreference(private val preferences: SharedPreferences, private val key: String) {

        operator fun getValue(thisRef: Any?, property: KProperty<*>): String? {
            return preferences.getString(key, null)
        }

        operator fun setValue(thisRef: Any?, property: KProperty<*>, value: String?) {
            value?.also {
                preferences.edit().putString(key, value).commit()
            }
        }
    }
}