package com.pnc.SecurityMobileApp.model


import com.google.gson.annotations.SerializedName

data class FinalizeAuthenticationResponse(
    @SerializedName("fidoAuthenticationResponse")
    val fidoAuthenticationResponse: String,
    @SerializedName("fidoResponseCode")
    val fidoResponseCode: String,
    @SerializedName("fidoResponseMessage")
    val fidoResponseMessage: String,
    @SerializedName("resumePath")
    val resumePath: String
)