package com.pnc.SecurityMobileApp.api

import android.content.Context
import com.google.gson.JsonObject
import com.pnc.SecurityMobileApp.BuildConfig
import com.pnc.SecurityMobileApp.data.AppPreferences
import com.pnc.SecurityMobileApp.model.CreateRegistrationResponse
import com.pnc.SecurityMobileApp.model.DeregisterAuthenticatorResponse
import com.pnc.SecurityMobileApp.model.ListAuthenticatorsResponse
import com.pnc.SecurityMobileApp.model.RegistrationInfo
import io.reactivex.Single
import okhttp3.ResponseBody
import retrofit2.http.*

interface MFAPingAccessService {

    @GET("/nonxml/oca.com/ocarndidentityservice/{envDescriptor}/IdentityXServices/rest/v1/users/{userId}/authenticators")
    fun listAuthenticators(
        @Header("Authorization") authorization: String,
        @Path("envDescriptor") envDescriptor: String,
        @Path("userId") userId: String,
        @Query("status") status: String? = "ACTIVE"
    ): Single<ListAuthenticatorsResponse>

    @POST("/nonxml/oca.com/ocarndidentityservice/{envDescriptor}/IdentityXServices/rest/v1/users/{userId}/authenticators/{authenticatorId}/archived")
    fun deregisterAuthenticator(
        @Header("Authorization") authorization: String,
        @Path("envDescriptor") envDescriptor: String,
        @Path("userId") userId: String,
        @Path("authenticatorId") authenticatorId: String
    ): Single<DeregisterAuthenticatorResponse>

    @POST("/nonxml/oca.com/ocarndidentityservice/{envDescriptor}/IdentityXServices/rest/v1/users/{userId}/registrationChallenges")
    fun createRegistrationRequest(
        @Header("Authorization") authorization: String,
        @Path("envDescriptor") envDescriptor: String,
        @Path("userId") userId: String,
        @Body registrationInfo: RegistrationInfo
    ): Single<CreateRegistrationResponse>

    @POST("/nonxml/oca.com/ocarndidentityservice/{envDescriptor}/IdentityXServices/rest/v1/users/{userId}/registrationChallenges/{regChallengeId}")
    fun updateRegistrationRequest(
        @Header("Authorization") authorization: String,
        @Path("envDescriptor") envDescriptor: String,
        @Path("userId") userId: String,
        @Path("regChallengeId") regChallengeId: String,
        @Body fidoRegResponse: JsonObject
    ): Single<ResponseBody>


    companion object {

        fun listAuthenticators(context: Context): Single<ListAuthenticatorsResponse> {
            val prefs = AppPreferences(context)
            return ApiHelper.getPingAccessService().listAuthenticators(
                "Bearer ${prefs.referenceToken}",
                BuildConfig.ENV_DESCRIPTOR,
                prefs.idxUserId ?: ""
            )
        }


        fun deregisterAuthenticator(
            context: Context,
            authenticatorId: String
        ): Single<DeregisterAuthenticatorResponse> {
            val prefs = AppPreferences(context)
            return ApiHelper.getPingAccessService().deregisterAuthenticator(
                "Bearer ${prefs.referenceToken}",
                BuildConfig.ENV_DESCRIPTOR,
                prefs.idxUserId ?: "",
                authenticatorId
            )
        }

        fun updateRegistrationRequest(
            context: Context,
            fidoRegResponse: String
        ): Single<ResponseBody> {
            val prefs = AppPreferences(context)
            val json = JsonObject().apply {
                addProperty("fidoRegistrationResponse", fidoRegResponse)
            }
            val regChallengeId: String = prefs.fidoRegistrationRequestId ?: ""
            return ApiHelper.getPingAccessService().updateRegistrationRequest(
                "Bearer ${prefs.referenceToken}",
                BuildConfig.ENV_DESCRIPTOR,
                prefs.idxUserId ?: "", regChallengeId, json
            )
        }


        fun createRegistrationRequest(
            context: Context,
            registrationInfo: RegistrationInfo
        ): Single<CreateRegistrationResponse> {
            val prefs = AppPreferences(context)
            return ApiHelper.getPingAccessService().createRegistrationRequest(
                "Bearer ${prefs.referenceToken}",
                BuildConfig.ENV_DESCRIPTOR,
                prefs.idxUserId ?: "", registrationInfo
            )
        }

        fun createRegistrationRequest(
            context: Context
        ): Single<CreateRegistrationResponse> {
            val registrationInfo = RegistrationInfo(
                policy = RegistrationInfo.Policy(
                    RegistrationInfo.Policy.Application("amg"),
                    policyId = "biometricRegistration"
                ),
                registration = RegistrationInfo.Registration(
                    RegistrationInfo.Registration.Application("amg"),
                    registrationId = AppPreferences(context).daonGuid ?: "",
                    user = RegistrationInfo.Registration.User(
                        AppPreferences(context).idxUserId ?: ""
                    )
                )
            )
            return createRegistrationRequest(context, registrationInfo)
        }
    }
}